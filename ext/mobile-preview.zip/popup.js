const btnOn = document.getElementById("on");
const btnOff = document.getElementById("off");

function paint(on) {
  btnOn.classList.toggle("on", on);
  btnOff.classList.toggle("on", !on);
}

chrome.runtime.sendMessage({ type: "state" }, r => paint(!!(r && r.on)));

btnOn.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "set", on: true }, r => paint(!!(r && r.on)));
});

btnOff.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "set", on: false }, r => paint(!!(r && r.on)));
});
