/* 网页 ↔ 扩展的桥：网页里点「手机 / 电脑」，这里把指令转给后台去改 kdocs.cn 的 UA。
   网页自己改不了 UA（UA 是浏览器禁止脚本设置的请求头），只有扩展能改，
   所以「在预览网页里双向切」这件事必须由这一小段脚本接一下。 */

(function () {
  try {
    document.documentElement.setAttribute("data-ccl-ext", "1");
  } catch (e) {}

  window.addEventListener("message", function (ev) {
    if (ev.source !== window) return;
    var d = ev.data;
    if (!d || d.ccl !== "ua") return;

    try {
      chrome.runtime.sendMessage({ type: "set", on: !!d.on }, function (res) {
        window.postMessage(
          { ccl: "ua-ack", ok: !!(res && res.ok), on: !!(res && res.on) },
          "*"
        );
      });
    } catch (e) {
      window.postMessage({ ccl: "ua-ack", ok: false, on: false }, "*");
    }
  }, false);
})();
