/* 只改 kdocs.cn 的 User-Agent，不动登录态（Cookie 照旧）。
   打开移动端 → 刷新页面，WPS 服务端就会按手机身份返回移动版。 */

const UA_MOBILE = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
const RULE_ID = 1;

async function apply(on) {
  // 先清掉旧规则，避免叠加
  await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [RULE_ID] });

  if (on) {
    await chrome.declarativeNetRequest.updateSessionRules({
      addRules: [{
        id: RULE_ID,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "user-agent", operation: "set", value: UA_MOBILE }
          ]
        },
        condition: {
          requestDomains: ["kdocs.cn"],
          resourceTypes: [
            "main_frame", "sub_frame", "xmlhttprequest", "script",
            "stylesheet", "image", "font", "media", "other"
          ]
        }
      }]
    });
  }

  await chrome.storage.local.set({ uaOn: !!on });
}

async function getState() {
  const s = await chrome.storage.local.get({ uaOn: false });
  return s.uaOn;
}

/* 供 popup 调用 */
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === "set") {
    apply(!!msg.on).then(async () => reply({ ok: true, on: await getState() }));
    return true;
  }
  if (msg && msg.type === "state") {
    getState().then(on => reply({ ok: true, on }));
    return true;
  }
});
